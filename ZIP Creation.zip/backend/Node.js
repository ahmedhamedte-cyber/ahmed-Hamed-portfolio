// backend/server.js

const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(cors()); 
app.use(express.json()); 

// Nodemailer Transporter Setup
const transporter = nodemailer.createTransport({
    service: 'gmail', // Change if using a different service (e.g., 'smtp.sendgrid.net')
    auth: {
        user: process.env.EMAIL_USER, 
        pass: process.env.EMAIL_PASS, 
    },
});

// Contact Form Submission Endpoint
app.post('/submit', async (req, res) => {
    const { name, email, message } = req.body;

    if (!name || !email || !message) {
        return res.status(400).json({ error: 'All fields are required.' });
    }

    try {
        const mailOptions = {
            from: process.env.EMAIL_USER,
            to: process.env.TO_EMAIL, // Your receiving email address
            subject: `New Contact from Portfolio: ${name}`,
            text: `Name: ${name}\nEmail: ${email}\nMessage:\n---\n${message}`,
            html: `<p><strong>Name:</strong> ${name}</p><p><strong>Email:</strong> ${email}</p><p><strong>Message:</strong></p><p>${message}</p>`,
        };

        await transporter.sendMail(mailOptions);
        
        console.log(`Email successfully sent from ${name} (${email})`);
        res.status(200).json({ message: 'Message sent successfully!' });

    } catch (error) {
        console.error('Error sending email:', error);
        res.status(500).json({ error: 'Failed to send message. Server error.' });
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server listening at http://localhost:${port}`);
});